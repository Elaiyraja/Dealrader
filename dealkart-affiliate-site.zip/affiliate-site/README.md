# 🛒 DealKart — Complete Amazon Affiliate Website

**Niche:** Student & Budget Tech (India)
**Live in:** 1 Day | Zero Coding Knowledge Needed

---

## 📁 FOLDER STRUCTURE

```
dealkart/
├── index.html       ← Main website (homepage + all pages)
├── style.css        ← All design & styling
├── script.js        ← Products, search, filter, modal
├── assets/
│   └── images/      ← Add product images here (optional)
└── README.md        ← This guide
```

---

## 🚀 STEP 1 — SET UP GITHUB (Free Hosting)

### 1.1 Create GitHub Account
1. Go to **github.com**
2. Click **Sign Up**
3. Enter your email, password, username
4. Verify your email

### 1.2 Create a New Repository
1. Click **"New"** (green button) or go to github.com/new
2. Repository name: `dealkart` (or any name)
3. Set to **Public** ← important for free hosting
4. ✅ Check "Add a README file"
5. Click **Create Repository**

### 1.3 Upload Your Files
1. Click **"Add file"** → **"Upload files"**
2. Drag and drop all 3 files:
   - `index.html`
   - `style.css`
   - `script.js`
3. Click **"Commit changes"**

### 1.4 Enable GitHub Pages (Free Hosting)
1. Go to your repository → **Settings**
2. Scroll to **"Pages"** (left sidebar)
3. Under "Source" → select **"Deploy from a branch"**
4. Branch: **main** | Folder: **/ (root)**
5. Click **Save**
6. Wait 2 minutes → your site is LIVE at:
   `https://YOUR-USERNAME.github.io/dealkart`

---

## 💰 STEP 2 — AMAZON ASSOCIATES SIGNUP

### How to Join (India)
1. Go to **affiliate-program.amazon.in**
2. Click **"Join Now for Free"**
3. Log in with your Amazon account
4. Fill in:
   - **Website URL:** your GitHub Pages URL
   - **Describe your website:** "Product review and comparison site for Indian students"
   - **Traffic source:** Social media + organic search
5. Enter your PAN card + bank details (for payments)
6. You have **180 days** to make your first sale after approval

### Get Your Affiliate Tag
After approval, your tag looks like: `yourname-21`
This is your **tracking ID** — it tells Amazon which sales came from you.

---

## 🔗 STEP 3 — ADD YOUR AFFILIATE LINKS

### How to Generate a Link
1. Log into **affiliate-program.amazon.in**
2. Open any Amazon product page
3. You'll see a **SiteStripe bar** at the top
4. Click **"Text"** → copy the link (it contains your tag)
   Example: `https://www.amazon.in/dp/B09G3KPKQS?tag=yourname-21`

### Update the Website
Open `script.js` and find this line at the top:
```javascript
const AFFILIATE_TAG = "YOUR_AFFILIATE_TAG-21";
```
Replace `YOUR_AFFILIATE_TAG` with your actual tag:
```javascript
const AFFILIATE_TAG = "dealkart-21";
```

**That's it!** All product links now have your tag automatically.

For specific products, update the `affiliate_url` field in the PRODUCTS array:
```javascript
affiliate_url: `https://www.amazon.in/dp/B09G3KPKQS?tag=${AFFILIATE_TAG}`,
```

---

## ➕ STEP 4 — ADD YOUR OWN PRODUCTS

Find the `PRODUCTS` array in `script.js`. Copy this template:

```javascript
{
  id: 13,                          // ← Unique number
  title: "Your Product Name",
  category: "audio",               // ← audio/charging/laptop/stationery/lighting
  emoji: "🎧",                    // ← Pick a fitting emoji
  price: 799,                      // ← Current sale price
  original_price: 1999,            // ← Original MRP
  rating: 4.3,                     // ← From Amazon
  reviews: 12000,                  // ← Number of ratings on Amazon
  badge: "New",                    // ← Any badge text
  badge_type: "orange",            // ← orange / green / gold
  description: "Write 1-2 sentences about the product.",
  features: [
    "Feature 1",
    "Feature 2",
    "Feature 3",
  ],
  affiliate_url: `https://www.amazon.in/dp/XXXXXXXXX?tag=${AFFILIATE_TAG}`,
  under999: true,                  // ← true if price ≤ ₹999
  popular: true                    // ← show as "popular"
},
```

---

## 📈 STEP 5 — SEO (Get Free Google Traffic)

The website already includes:
- Meta title & description
- Keywords tag
- Open Graph tags (for WhatsApp/social sharing)
- Mobile-responsive design
- Fast loading (no external JS libraries)

### Optional: Add Google Analytics
1. Go to **analytics.google.com**
2. Create a property → get your Measurement ID (G-XXXXXXX)
3. Add before `</head>` in `index.html`:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXX');
</script>
```

### Blog Posts for Organic Traffic
Create simple HTML pages like:
- `best-earbuds-under-1000.html`
- `student-laptop-accessories.html`
- `power-bank-buying-guide.html`

Target keywords like:
- "best earbuds under 1000 rupees"
- "budget power bank India 2024"
- "laptop accessories for students India"

---

## 📱 STEP 6 — PROMOTE & GET TRAFFIC

### Instagram Strategy
1. Create a page: @dealkart or @budgettechIndia
2. Post **daily deal stories** with product image + price
3. Put your GitHub Pages link in bio
4. Use hashtags: #TechDeals #StudentDeals #BudgetTech #AmazonIndia

### WhatsApp Strategy
1. Create a **WhatsApp Channel** named "DealKart Deals"
2. Post 1-2 deals daily (image + price + link)
3. Add to family/college groups with permission

### Telegram Strategy
1. Create a **Telegram Channel**: t.me/dealkart
2. Post deals with your affiliate links directly
3. Telegram is best for conversions in India!

### Day 1 Checklist
- [ ] Website live on GitHub Pages
- [ ] Amazon Associates approved
- [ ] AFFILIATE_TAG updated in script.js
- [ ] 3 product links verified
- [ ] Instagram page created
- [ ] WhatsApp Channel created
- [ ] First post shared

---

## 💸 EARNING POTENTIAL

| Category | Commission Rate |
|----------|----------------|
| Electronics | 4% |
| Mobile Accessories | 5–7% |
| Books/Stationery | 4% |
| Clothing | 9% |
| Shoes | 9% |

**Example:** Someone buys earbuds for ₹799 → you earn ~₹32
100 sales/month = ₹3,200/month passive income
500 sales/month = ₹16,000/month

Amazon pays via bank transfer when you reach ₹1,000.

---

## ⚠️ IMPORTANT LEGAL NOTES

1. **Always show the affiliate disclaimer** (already included in index.html)
2. Never claim "lowest price" or "guaranteed savings"
3. Don't use Amazon's logo without permission — use text links
4. Check Amazon Associates Operating Agreement for rules

---

## 🆘 COMMON PROBLEMS

| Problem | Solution |
|---------|----------|
| Site not loading | Check GitHub Pages is enabled |
| Links not working | Make sure affiliate_url has your tag |
| Products not showing | Check script.js for syntax errors |
| Mobile layout broken | Clear browser cache |

---

Built with ❤️ for Indian students. Good luck! 🚀
