// =============================================
//  DEALKART — AFFILIATE WEBSITE JAVASCRIPT
//  HOW TO UPDATE: Edit the PRODUCTS array below
//  Replace YOUR_AFFILIATE_TAG with your Amazon
//  Associates tracking ID (e.g. dealkart-21)
// =============================================

const AFFILIATE_TAG = "YOUR_AFFILIATE_TAG-21"; // ← CHANGE THIS

// ---- PRODUCT DATABASE ----
// To add a new product: copy one object, change the values.
// affiliate_url: Go to Amazon → product page → SiteStripe bar → Get Link → Text
const PRODUCTS = [
  {
    id: 1,
    title: "boAt Airdopes 141 TWS Earbuds",
    category: "audio",
    emoji: "🎧",
    price: 799,
    original_price: 2990,
    rating: 4.2,
    reviews: 45280,
    badge: "Best Seller",
    badge_type: "orange",
    description: "42-hour total playback, IPX4 water resistance, ASAP Charge. Perfect for students and daily commuters. Clear calls with mic.",
    features: ["42 Hours Total Playback", "ASAP™ Charge Technology", "IPX4 Water Resistant", "Touch Controls", "Bluetooth v5.0"],
    affiliate_url: `https://www.amazon.in/dp/B09G3KPKQS?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: true
  },
  {
    id: 2,
    title: "Mi Power Bank 3i 10000mAh",
    category: "charging",
    emoji: "⚡",
    price: 949,
    original_price: 1499,
    rating: 4.4,
    reviews: 62140,
    badge: "Top Pick",
    badge_type: "green",
    description: "Slim 10000mAh power bank with 18W fast charging. Charges iPhone and Android phones. Lightweight at 218g.",
    features: ["10000mAh Capacity", "18W Fast Charging", "Dual USB Ports", "Weight: 218g", "LED Charge Indicator"],
    affiliate_url: `https://www.amazon.in/dp/B08KZGGV95?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: true
  },
  {
    id: 3,
    title: "Portronics Hydra 10 Laptop Stand",
    category: "laptop",
    emoji: "💻",
    price: 699,
    original_price: 1299,
    rating: 4.1,
    reviews: 12400,
    badge: "46% OFF",
    badge_type: "orange",
    description: "Adjustable 6-angle laptop stand for better posture. Compatible with 10–16 inch laptops. Foldable and portable.",
    features: ["6 Adjustable Angles", "Non-Slip Silicone Pads", "For 10–16 Inch Laptops", "Foldable Design", "Aluminium Alloy Build"],
    affiliate_url: `https://www.amazon.in/dp/B09YMXQCPZ?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: false
  },
  {
    id: 4,
    title: "Portronics Toad 23 Wireless Mouse",
    category: "laptop",
    emoji: "🖱️",
    price: 449,
    original_price: 999,
    rating: 4.3,
    reviews: 8920,
    badge: "Under ₹500",
    badge_type: "green",
    description: "2.4GHz wireless mouse with 1600 DPI. USB nano receiver included. Silent clicks — great for libraries and hostels.",
    features: ["1600 DPI Optical Sensor", "2.4GHz Wireless", "Silent Click Buttons", "USB Nano Receiver", "3-Month Battery Life"],
    affiliate_url: `https://www.amazon.in/dp/B09F7YR5YZ?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: true
  },
  {
    id: 5,
    title: "Zebronics ZEB-AC2000 USB Hub",
    category: "laptop",
    emoji: "🔌",
    price: 349,
    original_price: 699,
    rating: 4.0,
    reviews: 5600,
    badge: "Must Have",
    badge_type: "gold",
    description: "4-port USB 2.0 hub. Plug and play — no drivers needed. Perfect for expanding slim laptop's USB ports.",
    features: ["4 USB 2.0 Ports", "Plug & Play", "Data Transfer 480Mbps", "Compact & Portable", "LED Indicator"],
    affiliate_url: `https://www.amazon.in/dp/B07DQLQR1D?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: false
  },
  {
    id: 6,
    title: "Wipro LED Desk Lamp Flexo",
    category: "lighting",
    emoji: "💡",
    price: 549,
    original_price: 1200,
    rating: 4.2,
    reviews: 9870,
    badge: "Eye Care",
    badge_type: "green",
    description: "Eye-care LED desk lamp with flexible neck. Touch dimmer with 3 brightness levels. USB charging port on base.",
    features: ["3 Brightness Levels", "Touch Dimmer Control", "USB Charging Port", "Flexible 360° Neck", "Energy Saving LED"],
    affiliate_url: `https://www.amazon.in/dp/B07CKWJQBY?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: true
  },
  {
    id: 7,
    title: "JBL C50HI In-Ear Headphones",
    category: "audio",
    emoji: "🎵",
    price: 399,
    original_price: 799,
    rating: 4.1,
    reviews: 34100,
    badge: "JBL Sound",
    badge_type: "orange",
    description: "Wired earphones with JBL Pure Bass sound. 1-button mic for calls. 3.5mm jack works with all phones and laptops.",
    features: ["JBL Pure Bass Sound", "1-Button Mic/Remote", "3.5mm Universal Jack", "1.2m Cable", "3 Ear Tip Sizes"],
    affiliate_url: `https://www.amazon.in/dp/B075SMY9B6?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: true
  },
  {
    id: 8,
    title: "Classmate Exercise Notebook (Pack of 6)",
    category: "stationery",
    emoji: "📓",
    price: 189,
    original_price: 240,
    rating: 4.5,
    reviews: 18500,
    badge: "Top Seller",
    badge_type: "gold",
    description: "Pack of 6 ruled notebooks (200 pages each). Best-quality paper for college notes. Durable cover.",
    features: ["Pack of 6 Notebooks", "200 Pages Each", "Ruled 70 GSM Paper", "Durable Cover", "A4 Size"],
    affiliate_url: `https://www.amazon.in/dp/B07KQKHFWG?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: false
  },
  {
    id: 9,
    title: "Anker PowerCore Essential 20000mAh",
    category: "charging",
    emoji: "🔋",
    price: 2299,
    original_price: 3499,
    rating: 4.6,
    reviews: 28700,
    badge: "Premium",
    badge_type: "gold",
    description: "Anker's 20000mAh high-capacity power bank. Charges MacBook, iPad & smartphones. Multi-device charging.",
    features: ["20000mAh Capacity", "High-Speed Charging", "2 USB-A Ports", "PowerIQ Technology", "18-Month Warranty"],
    affiliate_url: `https://www.amazon.in/dp/B08LG2X98P?tag=${AFFILIATE_TAG}`,
    under999: false,
    popular: true
  },
  {
    id: 10,
    title: "Logitech M235 Wireless Mouse",
    category: "laptop",
    emoji: "🖱️",
    price: 1295,
    original_price: 1995,
    rating: 4.5,
    reviews: 41200,
    badge: "Logitech",
    badge_type: "green",
    description: "Logitech M235 with advanced optical tracking. Compact wireless mouse. 12-month battery. Works on almost any surface.",
    features: ["Advanced Optical Tracking", "12-Month Battery Life", "Nano USB Receiver", "Compact Design", "3-Year Warranty"],
    affiliate_url: `https://www.amazon.in/dp/B00BCNEXRE?tag=${AFFILIATE_TAG}`,
    under999: false,
    popular: true
  },
  {
    id: 11,
    title: "Portronics Breeze 10 Cooling Pad",
    category: "laptop",
    emoji: "❄️",
    price: 799,
    original_price: 1499,
    rating: 4.0,
    reviews: 7650,
    badge: "Stay Cool",
    badge_type: "orange",
    description: "Laptop cooling pad with 2 fans for laptops up to 15.6 inch. USB-powered, adjustable height stand included.",
    features: ["2 High-Speed Fans", "For Upto 15.6 Inch", "USB Powered", "Adjustable Height", "Silent Operation"],
    affiliate_url: `https://www.amazon.in/dp/B084P12WPC?tag=${AFFILIATE_TAG}`,
    under999: true,
    popular: false
  },
  {
    id: 12,
    title: "Fastrack Reflex 3.0 Smartwatch",
    category: "wearable",
    emoji: "⌚",
    price: 1995,
    original_price: 3995,
    rating: 4.1,
    reviews: 22400,
    badge: "50% OFF",
    badge_type: "orange",
    description: "Budget fitness tracker with heart rate monitor, 10-day battery, and water resistance. Track steps, sleep, and calories.",
    features: ["Heart Rate Monitor", "10-Day Battery", "IP67 Water Resistant", "Step & Sleep Tracking", "Notification Alerts"],
    affiliate_url: `https://www.amazon.in/dp/B07BDHBLNF?tag=${AFFILIATE_TAG}`,
    under999: false,
    popular: false
  }
];

// ---- STATE ----
let currentCategory = 'all';
let currentSort = 'popular';
let searchQuery = '';

// ---- RENDER PRODUCTS ----
function renderProducts() {
  const grid = document.getElementById('productsGrid');
  let filtered = [...PRODUCTS];

  // Category filter
  if (currentCategory === 'under999') {
    filtered = filtered.filter(p => p.under999);
  } else if (currentCategory !== 'all') {
    filtered = filtered.filter(p => p.category === currentCategory);
  }

  // Search filter
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(p =>
      p.title.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q)
    );
  }

  // Sort
  if (currentSort === 'price-low')  filtered.sort((a, b) => a.price - b.price);
  if (currentSort === 'price-high') filtered.sort((a, b) => b.price - a.price);
  if (currentSort === 'rating')     filtered.sort((a, b) => b.rating - a.rating);
  if (currentSort === 'popular')    filtered.sort((a, b) => b.reviews - a.reviews);

  if (filtered.length === 0) {
    grid.innerHTML = `<div class="no-results">
      <h3>😕 No products found</h3>
      <p>Try a different search or category.</p>
    </div>`;
    return;
  }

  grid.innerHTML = filtered.map((p, i) => `
    <div class="product-card" style="animation-delay:${i * 0.06}s" onclick="openModal(${p.id})">
      <div class="card-img">
        <span style="font-size:5rem;">${p.emoji}</span>
        ${p.badge ? `<div class="card-badge ${p.badge_type === 'green' ? 'green' : p.badge_type === 'gold' ? 'gold' : ''}">${p.badge}</div>` : ''}
      </div>
      <div class="card-body">
        <div class="card-category">${p.category}</div>
        <div class="card-title">${p.title}</div>
        <div class="card-rating">
          <span class="stars">${getStars(p.rating)}</span>
          <span class="rating-count">${p.rating} (${formatCount(p.reviews)})</span>
        </div>
        <div class="card-price">
          <span class="price-current">₹${p.price.toLocaleString('en-IN')}</span>
          <span class="price-old">₹${p.original_price.toLocaleString('en-IN')}</span>
          <span class="price-save">${Math.round((1 - p.price/p.original_price)*100)}% off</span>
        </div>
        <a href="${p.affiliate_url}" target="_blank" rel="noopener noreferrer sponsored"
           class="btn-amazon" onclick="event.stopPropagation(); trackClick(${p.id})">
          🛒 Buy on Amazon
        </a>
      </div>
    </div>
  `).join('');
}

// ---- RENDER UNDER ₹999 MINI GRID ----
function renderUnder999() {
  const grid = document.getElementById('under999Grid');
  const items = PRODUCTS.filter(p => p.under999).slice(0, 6);
  grid.innerHTML = items.map(p => `
    <div class="mini-card" onclick="openModal(${p.id})">
      <div class="emoji">${p.emoji}</div>
      <div class="mini-title">${p.title}</div>
      <div class="mini-price">₹${p.price.toLocaleString('en-IN')}</div>
    </div>
  `).join('');
}

// ---- FILTER BY CATEGORY ----
function filterCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll('.cat-card').forEach(c => c.classList.remove('active'));
  event.currentTarget && event.currentTarget.classList.add('active');
  renderProducts();
  document.getElementById('featured').scrollIntoView({ behavior: 'smooth' });
}

// ---- SORT ----
function sortProducts(type) {
  currentSort = type;
  document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
  event.currentTarget.classList.add('active');
  renderProducts();
}

// ---- SEARCH ----
function filterProducts() {
  searchQuery = document.getElementById('searchInput').value;
  renderProducts();
}

// ---- TOGGLE SEARCH BAR ----
function toggleSearch() {
  const bar = document.getElementById('searchBar');
  bar.classList.toggle('open');
  if (bar.classList.contains('open')) {
    document.getElementById('searchInput').focus();
  }
}

// ---- MOBILE NAV ----
function toggleNav() {
  document.getElementById('nav').classList.toggle('open');
}

// ---- MODAL ----
function openModal(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  document.getElementById('modalContent').innerHTML = `
    <div class="modal-body">
      <div class="modal-emoji">${p.emoji}</div>
      <div class="modal-category">${p.category}</div>
      <div class="modal-title">${p.title}</div>
      <div class="modal-desc">${p.description}</div>
      <div class="modal-price-row">
        <span class="price-current" style="font-size:1.6rem;">₹${p.price.toLocaleString('en-IN')}</span>
        <span class="price-old">₹${p.original_price.toLocaleString('en-IN')}</span>
        <span class="price-save">${Math.round((1 - p.price/p.original_price)*100)}% off</span>
      </div>
      <div class="card-rating" style="margin-bottom:20px;">
        <span class="stars">${getStars(p.rating)}</span>
        <span class="rating-count">${p.rating}/5 · ${formatCount(p.reviews)} ratings on Amazon</span>
      </div>
      <ul class="modal-features">
        ${p.features.map(f => `<li>${f}</li>`).join('')}
      </ul>
      <a href="${p.affiliate_url}" target="_blank" rel="noopener noreferrer sponsored"
         class="btn-amazon-lg" onclick="trackClick(${p.id})">
        🛒 Buy on Amazon.in →
      </a>
      <p style="font-size:0.72rem;color:var(--muted);text-align:center;margin-top:12px;">
        You'll be redirected to Amazon.in. Price may vary.
      </p>
    </div>
  `;
  document.getElementById('modalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

// Close modal on Escape key
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

// ---- HELPERS ----
function getStars(rating) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5 ? '½' : '';
  return '★'.repeat(full) + half;
}

function formatCount(n) {
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n;
}

// ---- ANALYTICS (replace with real tracking) ----
function trackClick(productId) {
  const p = PRODUCTS.find(x => x.id === productId);
  console.log(`[DealKart] Click tracked: ${p?.title}`);
  // Add Google Analytics event here if needed:
  // gtag('event', 'affiliate_click', { product: p?.title });
}

// ---- HEADER SCROLL EFFECT ----
window.addEventListener('scroll', () => {
  document.getElementById('header').classList.toggle('scrolled', window.scrollY > 20);
  document.getElementById('backTop').classList.toggle('visible', window.scrollY > 400);
});

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  renderProducts();
  renderUnder999();
});
